﻿namespace FirstMVC.Tests.Features
{
    public class RatingResult
    {
        public int Rating { get; set; }
    }
}